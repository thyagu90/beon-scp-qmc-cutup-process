package com.beon.scp.qmc.cutup.model;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Setter
@Getter
@NoArgsConstructor
public class CutUpPublishRequestModel {
    private String supplier;
    private String approver;
    private String heatCode;
    private String partNumber;
}
