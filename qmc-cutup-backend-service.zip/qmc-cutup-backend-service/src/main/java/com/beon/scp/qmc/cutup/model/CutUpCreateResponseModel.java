package com.beon.scp.qmc.cutup.model;

import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Data
@Setter
@Getter
@NoArgsConstructor
public class CutUpCreateResponseModel {
    private int statusCode;
    private String error;
    private String message;
}
