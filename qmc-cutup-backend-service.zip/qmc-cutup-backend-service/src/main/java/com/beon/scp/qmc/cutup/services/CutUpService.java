package com.beon.scp.qmc.cutup.services;


import com.beon.scp.qmc.cutup.model.CutUpCreateResponseModel;
import com.beon.scp.qmc.cutup.model.CutUpDeleteResponseModel;
import com.beon.scp.qmc.cutup.model.CutUpPublishRequestModel;
import com.beon.scp.qmc.cutup.model.CutUpResponseModel;
import com.beon.scp.qmc.cutup.model.dto.CamundaMessageDto;
import com.beon.scp.qmc.cutup.model.entity.CutUpEntity;
import com.beon.scp.qmc.cutup.respository.CutUpRespository;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Slf4j
@AllArgsConstructor
@Service
public class CutUpService {

    private final CutUpRespository respository ;

    private final KafkaTemplate<String, CamundaMessageDto> kafkaTemplate;

    public CutUpCreateResponseModel publish(CutUpPublishRequestModel model){
        CutUpCreateResponseModel resp = new CutUpCreateResponseModel();
        try{
            //save into database

            CutUpEntity entity = new CutUpEntity();
            UUID uuid = UUID.randomUUID();
            entity.setCutUpId(uuid.toString());
            entity.setSupplier(model.getSupplier());
            entity.setApprover(model.getApprover());
            entity.setPartNumber(model.getPartNumber());
            entity.setHeatCode(model.getHeatCode());
            entity.setStatus("published");

            try {
                CutUpEntity entityResult = respository.save(entity);
                if (entityResult.getCutUpId()!=null) {
                    resp.setMessage("User Saved Successfully");
                    resp.setStatusCode(200);
                }
            }catch (Exception e){
                resp.setStatusCode(500);
                resp.setError(e.getMessage());
            }

            // producer message to kafka
            CamundaMessageDto camundaMessageDto = new CamundaMessageDto();
            camundaMessageDto.setCorrelationId(entity.getCutUpId());
            camundaMessageDto.setDto(entity);
            kafkaTemplate.send("cutup_published_topic", camundaMessageDto);

        } catch(Exception ex){
            ex.printStackTrace();
        }

        return resp;
    }

    public void saveApprovalStatus(CamundaMessageDto camundaMessageDto) {
        var optCutUpId = respository.findbyCutUpId(camundaMessageDto.getDto().getCutUpId()).stream().findFirst();
        if(optCutUpId.isEmpty()){
            log.error("cutup having id"+camundaMessageDto.getDto().getCutUpId()+" is not found");
            return;
        }
        var status = camundaMessageDto.getDto().getStatus();
        var cutup = optCutUpId.get();
        cutup.setStatus(status);
        respository.save(cutup);
        log.info("status updated for cutup having id"+camundaMessageDto.getDto().getCutUpId());
    }

    public CutUpResponseModel getAllCutUp() {
        CutUpResponseModel reqRes = new CutUpResponseModel();
        try {
        List<CutUpEntity> result = respository.findAll();
        if (!result.isEmpty()) {
            reqRes.setCutUpList(result);
            reqRes.setStatusCode(200);
            reqRes.setMessage("Successful");
        } else {
            reqRes.setStatusCode(200);
            reqRes.setMessage("No cutup found");
        }
        return reqRes;
    } catch (Exception e) {
        reqRes.setStatusCode(500);
        reqRes.setMessage("Error occurred: " + e.getMessage());
        return reqRes;
    }
    }

    public CutUpDeleteResponseModel deleteCutUp(String cutUpId) {
        CutUpDeleteResponseModel reqRes = new CutUpDeleteResponseModel();
            try {
                Optional<CutUpEntity> userOptional = respository.findbyCutUpId((cutUpId)).stream().findFirst();
                if (userOptional.isPresent()) {
                    respository.deleteByCutUpId(cutUpId);
                    reqRes.setStatusCode(200);
                    reqRes.setMessage("CutUp deleted successfully");
                } else {
                    reqRes.setStatusCode(404);
                    reqRes.setMessage("CutUp not found for deletion");
                }
            } catch (Exception e) {
                reqRes.setStatusCode(500);
                reqRes.setMessage("Error occurred while deleting CutUp: " + e.getMessage());
            }
            return reqRes;
    }

    public void archiveDocument(CamundaMessageDto camundaMessageDto) {
        log.info("message archived successfully");

        //send notification back
        kafkaTemplate.send("cutup_archive_ack_topic", camundaMessageDto);

    }

    //todo - duplicate code
    public CutUpCreateResponseModel save(CutUpPublishRequestModel model) {
        CutUpCreateResponseModel resp = new CutUpCreateResponseModel();
        try {
            //save into database
            CutUpEntity entity = new CutUpEntity();
            UUID uuid = UUID.randomUUID();
            entity.setCutUpId(uuid.toString());
            entity.setSupplier(model.getSupplier());
            entity.setApprover(model.getApprover());
            entity.setPartNumber(model.getPartNumber());
            entity.setHeatCode(model.getHeatCode());
            entity.setStatus("saved");

            try {
                CutUpEntity entityResult = respository.save(entity);
                if (entityResult.getCutUpId() != null) {
                    resp.setMessage("User Saved Successfully");
                    resp.setStatusCode(200);
                }
            } catch (Exception e) {
                resp.setStatusCode(500);
                resp.setError(e.getMessage());
            }
        } catch(Exception ex){
            ex.printStackTrace();
        }
        return resp;
    }
}
