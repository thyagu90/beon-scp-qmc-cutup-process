package com.beon.scp.qmc.cutup.respository;


import com.beon.scp.qmc.cutup.model.entity.CutUpEntity;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

import java.util.List;

public interface CutUpRespository extends JpaRepository<CutUpEntity, Integer> {

    @Query(value ="SELECT * FROM SccCutUp WHERE cutUpId=?1",nativeQuery = true)
    List<CutUpEntity> findbyCutUpId(String cutUpId);

    @Query(value ="Delete from SccCutUp WHERE cutUpId=?1",nativeQuery = true)
    void deleteByCutUpId(String cutUpId);
}
