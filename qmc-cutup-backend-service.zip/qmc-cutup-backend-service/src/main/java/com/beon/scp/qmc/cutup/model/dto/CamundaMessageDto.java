package com.beon.scp.qmc.cutup.model.dto;



import com.beon.scp.qmc.cutup.model.entity.CutUpEntity;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class CamundaMessageDto implements Serializable {
    private String correlationId;
    private CutUpEntity dto;
}
