package com.beon.scp.qmc.cutup.consumer;


import com.beon.scp.qmc.cutup.model.dto.CamundaMessageDto;
import com.beon.scp.qmc.cutup.services.CutUpService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Component;

@Component
@RequiredArgsConstructor
@Slf4j
public class ApprovalNotificationConsumer {

    private final CutUpService cutUpService;

    @KafkaListener(topics = "cutup_approved_notification_topic")
    public void startMessageProcess(CamundaMessageDto camundaMessageDto) {
        cutUpService.saveApprovalStatus(camundaMessageDto);
    }
}
