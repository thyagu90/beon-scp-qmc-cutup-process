package com.beon.scp.qmc.cutup.model;


import com.beon.scp.qmc.cutup.model.entity.CutUpEntity;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

import java.util.List;

@Data
@Setter
@Getter
@NoArgsConstructor
public class CutUpResponseModel {
    private int statusCode;
    private String error;
    private String message;
    private List<CutUpEntity> cutUpList;
}
