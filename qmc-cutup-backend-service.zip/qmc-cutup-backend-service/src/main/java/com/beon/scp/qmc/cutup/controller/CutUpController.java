package com.beon.scp.qmc.cutup.controller;


import com.beon.scp.qmc.cutup.model.CutUpCreateResponseModel;
import com.beon.scp.qmc.cutup.model.CutUpDeleteResponseModel;
import com.beon.scp.qmc.cutup.model.CutUpPublishRequestModel;
import com.beon.scp.qmc.cutup.model.CutUpResponseModel;
import com.beon.scp.qmc.cutup.services.CutUpService;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.logging.Logger;

@RestController
@RequestMapping("/cutup")
@RequiredArgsConstructor
@Slf4j
public class CutUpController {
    private final static Logger LOGGER = Logger.getLogger(CutUpController.class.getName());

    private final CutUpService cutUpService;

    @PostMapping("/publish")
    public CutUpCreateResponseModel publishProcess(@RequestBody CutUpPublishRequestModel cutUpPublishRequestModel){
        log.info("Received Published CutUp Request " + cutUpPublishRequestModel.toString());
        return cutUpService.publish(cutUpPublishRequestModel);
    }

    @PostMapping("/save")
    public CutUpCreateResponseModel saveProcess(@RequestBody CutUpPublishRequestModel cutUpPublishRequestModel){
        log.info("Received save CutUp Request " + cutUpPublishRequestModel.toString());
        return cutUpService.save(cutUpPublishRequestModel);
    }


    @GetMapping("/getAllCutUp")
    public ResponseEntity<CutUpResponseModel> getAllCutUp(){
        return ResponseEntity.ok(cutUpService.getAllCutUp());
    }

    @DeleteMapping("/delete/{cutUpId}")
    public ResponseEntity<CutUpDeleteResponseModel> deleteCutUp(@PathVariable String cutUpId){
        return ResponseEntity.ok(cutUpService.deleteCutUp(cutUpId));
    }
}
