package com.beon.scp.qmc.cutup.model.entity;

import jakarta.persistence.Entity;
import jakarta.persistence.Id;
import jakarta.persistence.Table;
import lombok.Data;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

@Entity
@Data
@Setter
@Getter
@NoArgsConstructor
@Table(name = "SccCutUp")
public class CutUpEntity {
    @Id
    private String cutUpId;
    private String supplier;
    private String approver;
    private String heatCode;
    private String partNumber;
    private String status;
}
